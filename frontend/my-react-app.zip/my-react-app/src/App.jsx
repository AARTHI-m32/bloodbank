import Home from "./components/Home"
import Nav from "./components/Nav"
import Login from "./components/Login"
import "./App.css" 
const App = () => {
  return(
    <div>  
    <Login/>
    </div>
  )
}
export default App